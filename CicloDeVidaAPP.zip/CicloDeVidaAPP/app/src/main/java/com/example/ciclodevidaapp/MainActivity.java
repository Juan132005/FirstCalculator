package com.example.ciclodevidaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "In onCreate", Toast.LENGTH_SHORT).show();
        Log.i("Mi_mensaje","In onCreate de Juan Andrés");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "In onStart", Toast.LENGTH_SHORT).show();
        Log.i("Mi_mensaje","In onStart de Juan Andrés");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "In onResume", Toast.LENGTH_SHORT).show();
        Log.i("Mi_mensaje","In onResume de Juan Andrés");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "In onPause", Toast.LENGTH_SHORT).show();
        Log.i("Mi_mensaje","In onPause de Juan Andrés");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "In onStop", Toast.LENGTH_SHORT).show();
        Log.i("Mi_mensaje","In onStop de Juan Andrés");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "In onDestroy", Toast.LENGTH_SHORT).show();
        Log.i("Mi_mensaje","In onDestroy de Juan Andrés");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(this, "In onRestart", Toast.LENGTH_SHORT).show();
        Log.i("Mi_mensaje","In onRestart de Juan Andrés");
    }
}