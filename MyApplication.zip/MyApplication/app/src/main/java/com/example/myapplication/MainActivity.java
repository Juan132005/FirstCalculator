package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

        TextView TVResultado;
        EditText Etnum1,Etnum2;
        Button Btsumar,Btrestar,Btmultip,Btdividir;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TVResultado=findViewById(R.id.tv_Resultado);
        Etnum1=findViewById(R.id.et_num1);
        Etnum2=findViewById(R.id.et_num2);
        Btsumar=findViewById(R.id.btn_sumar);
        Btrestar=findViewById(R.id.btn_restar);
        Btmultip=findViewById(R.id.btn_multip);
        Btdividir=findViewById(R.id.btn_dividir);
    }
}